import { TopNav } from '@/components/TopNav';
import { Hero } from '@/components/Hero';
import { Features } from '@/components/Features';
import { Showcase } from '@/components/Showcase';
import { Pricing } from '@/components/Pricing';
import { Faqs } from '@/components/Faqs';
import { FinalCTA } from '@/components/FinalCTA';
import { DoodleBackground } from '@/components/DoodleBackground';

export default function Home() {
  return (
    <main className="relative min-h-screen w-full bg-white overflow-hidden flex flex-col selection:bg-brand-blue selection:text-white">
      {/* Background Layer */}
      <DoodleBackground />

      {/* Navigation */}
      <TopNav />

      {/* Main Content Area */}
      <div className="flex-grow flex flex-col items-center justify-center pt-[40px]">
        <Hero />
        <Features />
        <Showcase />
        <Pricing />
        <Faqs />
        <FinalCTA />
      </div>
    </main>
  );
}
