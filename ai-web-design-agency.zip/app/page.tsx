import React from 'react';
import { Navbar } from '@/components/Navbar';
import { Hero } from '@/components/Hero';
import { Partners } from '@/components/Partners';
import { HowItWorks } from '@/components/HowItWorks';
import { FeaturesChess } from '@/components/FeaturesChess';
import { FeaturesGrid } from '@/components/FeaturesGrid';
import { Stats } from '@/components/Stats';
import { Testimonials } from '@/components/Testimonials';
import { Footer } from '@/components/Footer';

export default function Page() {
  return (
    <main className="bg-black min-h-screen w-full overflow-x-hidden flex flex-col">
      <Navbar />
      <Hero />
      <Partners />
      <HowItWorks />
      <FeaturesChess />
      <FeaturesGrid />
      <Stats />
      <Testimonials />
      <Footer />
    </main>
  );
}
