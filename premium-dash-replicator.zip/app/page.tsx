import { DashboardHeader } from "@/components/DashboardHeader";
import { MetricsRow } from "@/components/MetricsRow";
import { MainGrid } from "@/components/MainGrid";
import { DashboardLayout } from "@/components/DashboardLayout";

export default function DashboardPage() {
  return (
    <DashboardLayout>
      <DashboardHeader />
      <MetricsRow />
      <MainGrid />
    </DashboardLayout>
  );
}
