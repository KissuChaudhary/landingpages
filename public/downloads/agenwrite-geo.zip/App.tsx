import React from 'react';
import { Navbar, Footer } from './components/Layout';
import { BentoGrid } from './components/BentoGrid';
import { ProblemSolution } from './components/ProblemSolution';
import { ComparisonTable } from './components/ComparisonTable';
import { Bot, Cpu, Layers, GitBranch, Sparkles, ArrowRight, Fingerprint, Globe, FileCheck } from 'lucide-react';
import { ActionButton } from './components/ActionButton';
import { Crosshair } from './components/Crosshair';
import { PixelBackground } from './components/ui/PixelBackground';

const App: React.FC = () => {
  return (
    // OUTER FRAME: Dark Theme Pad
    <div className="min-h-screen bg-[#050505] p-3 md:p-8 font-sans selection:bg-zinc-700 selection:text-white flex flex-col items-center">
      
      {/* MAIN INTERFACE BOX */}
      <div className="relative w-full max-w-[1400px] bg-background border border-border shadow-2xl shadow-black flex flex-col">
        
        <Crosshair className="-top-3 -left-3" />
        <Crosshair className="-top-3 -right-3" />
        <Crosshair className="-bottom-3 -left-3" />
        <Crosshair className="-bottom-3 -right-3" />

        {/* ROW 1: NAVBAR */}
        <div className="relative z-20 bg-background">
            <Navbar />
            <Crosshair className="-bottom-3 -left-3" />
            <Crosshair className="-bottom-3 -right-3" />
        </div>

        {/* ROW 2: HERO SECTION (Centered, No Visual, Gradient Text BG) */}
        <div className="relative border-b border-border overflow-hidden bg-black min-h-[800px] flex flex-col justify-center">
            {/* New Pixel Background - Dense, Blue/Cyan, Fast */}
            <PixelBackground />

            {/* Radial Gradient Overlay: Darkens the center for text readability without a "box" */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,0,0,0.85)_0%,rgba(0,0,0,0.4)_50%,rgba(0,0,0,0)_100%)] pointer-events-none z-0" />
            
            {/* Vignette at the bottom to blend into next section */}
            <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-black to-transparent z-10"></div>

            <section className="relative z-20 px-6 md:px-12 flex flex-col items-center text-center max-w-4xl mx-auto pt-20 pb-32">
                
                {/* Badge */}
                <div className="inline-block mb-10 animate-in fade-in slide-in-from-bottom-4 duration-700">
                    <div className="flex items-center gap-3 rounded-full border border-zinc-800 bg-zinc-900/50 px-4 py-1.5 text-xs font-medium text-muted backdrop-blur-md">
                        <span className="bg-zinc-700 text-white px-1.5 py-0.5 rounded-[2px] text-[10px] font-bold tracking-wider">NEW</span>
                        <span className="text-zinc-300">Try Fuse: Multi-Agent Layer</span>
                    </div>
                </div>

                {/* Main Heading */}
                <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold tracking-tight text-white mb-8 leading-[1.05] drop-shadow-2xl animate-in fade-in slide-in-from-bottom-6 duration-1000 delay-100">
                    Get agentic AI to <br/>
                    work on your <br/>
                    <span className="text-white">workflows</span>
                </h1>

                {/* Subtitle */}
                <p className="text-zinc-400 text-lg md:text-xl max-w-2xl mb-12 leading-relaxed font-light drop-shadow-md animate-in fade-in slide-in-from-bottom-8 duration-1000 delay-200">
                    Automate repetitive tasks and focus on what matters most. Less friction, more flow.
                </p>

                {/* CTA Button - Reverted to ActionButton with brackets */}
                <div className="animate-in fade-in slide-in-from-bottom-10 duration-1000 delay-300">
                     <ActionButton variant="primary" className="px-10 py-5 text-base shadow-[0_0_30px_rgba(255,255,255,0.1)]">
                        Get Started
                     </ActionButton>
                </div>
            </section>

            {/* Trusted By Footer (Inside Hero) */}
            <div className="absolute bottom-0 left-0 w-full z-20 border-t border-white/5 bg-black/40 backdrop-blur-sm py-8">
                <div className="max-w-7xl mx-auto px-6 md:px-12 flex flex-col md:flex-row items-center justify-between gap-8">
                    {/* Fake Logos using Fonts */}
                    <div className="flex items-center gap-12 opacity-50 grayscale hover:grayscale-0 transition-all duration-500">
                         <span className="font-serif text-2xl text-white font-bold tracking-tighter">Pipelinx.co</span>
                         <span className="font-sans text-xl text-white font-black tracking-tight">Ephicient®</span>
                         <span className="font-mono text-xl text-white font-bold">DUNHA</span>
                    </div>

                    <div className="text-left md:text-right max-w-xs">
                        <p className="text-sm text-zinc-500 font-medium leading-snug">
                            Powering teams inside the world's most innovative companies.
                        </p>
                    </div>
                </div>
            </div>
            
            <Crosshair className="-bottom-3 -left-3" />
            <Crosshair className="-bottom-3 -right-3" />
        </div>

        {/* ROW 4: PROBLEM & SOLUTION */}
        <div className="relative">
             <ProblemSolution />
             <Crosshair className="-bottom-3 -left-3" />
             <Crosshair className="-bottom-3 -right-3" />
        </div>

        {/* ROW 5: HOW IT WORKS (PROTOCOL) - Replaced Terminal with Grid */}
        <div className="relative border-b border-border py-24 px-6 md:px-12 bg-background">
            <div className="max-w-6xl mx-auto">
                
                {/* Section Header */}
                <div className="mb-16 md:text-center max-w-3xl mx-auto">
                    <span className="font-mono text-[10px] tracking-widest text-zinc-500 uppercase border border-zinc-800 px-2 py-1 bg-zinc-900/50">
                        [02] THE PROTOCOL
                    </span>
                    <h2 className="mt-6 text-3xl md:text-4xl font-serif text-white leading-tight">
                        Three steps to <br/>
                        <span className="text-zinc-500">Autonomous Authority.</span>
                    </h2>
                </div>

                {/* Shared Border Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 border border-zinc-800 bg-zinc-900/10">
                    
                    {/* STEP 1 */}
                    <div className="relative p-10 group hover:bg-zinc-900/40 transition-all border-b md:border-b-0 md:border-r border-zinc-800">
                        {/* Corner Accents */}
                        <div className="absolute top-0 left-0 w-2 h-2 border-t border-l border-zinc-600 opacity-50"></div>
                        <div className="absolute top-0 right-0 w-2 h-2 border-t border-r border-zinc-600 opacity-50 md:hidden"></div>

                        <div className="mb-6 opacity-30 group-hover:opacity-100 transition-opacity">
                            <Fingerprint size={32} className="text-white" strokeWidth={1.5} />
                        </div>
                        <span className="text-xs font-mono text-zinc-500 mb-2 block">Step_01</span>
                        <h3 className="text-xl text-white font-medium mb-3">Ingest & Analyze</h3>
                        <p className="text-sm text-zinc-500 leading-relaxed">
                            We don't just ask for a topic. We ingest your previous 50 articles, mapping sentence structure, vocabulary density, and formatting patterns to build a "Style DNA" file.
                        </p>
                    </div>

                    {/* STEP 2 */}
                    <div className="relative p-10 group hover:bg-zinc-900/40 transition-all border-b md:border-b-0 md:border-r border-zinc-800">
                        {/* Corner Accents */}
                        <div className="absolute top-0 left-0 w-2 h-2 border-t border-l border-zinc-600 opacity-50 md:hidden"></div>
                        
                        <div className="mb-6 opacity-30 group-hover:opacity-100 transition-opacity">
                            <Globe size={32} className="text-white" strokeWidth={1.5} />
                        </div>
                        <span className="text-xs font-mono text-zinc-500 mb-2 block">Step_02</span>
                        <h3 className="text-xl text-white font-medium mb-3">Live Recursive Research</h3>
                        <p className="text-sm text-zinc-500 leading-relaxed">
                            The agent browses live URLs to gather 2024/2025 data. It cross-references claims against multiple sources, discarding hallucinations and building a verified citation map.
                        </p>
                    </div>

                    {/* STEP 3 */}
                    <div className="relative p-10 group hover:bg-zinc-900/40 transition-all">
                        {/* Corner Accents */}
                        <div className="absolute top-0 right-0 w-2 h-2 border-t border-r border-zinc-600 opacity-50"></div>
                        <div className="absolute top-0 left-0 w-2 h-2 border-t border-l border-zinc-600 opacity-50 md:hidden"></div>
                        <div className="absolute bottom-0 right-0 w-2 h-2 border-b border-r border-zinc-600 opacity-50"></div>

                        <div className="mb-6 opacity-30 group-hover:opacity-100 transition-opacity">
                            <FileCheck size={32} className="text-white" strokeWidth={1.5} />
                        </div>
                        <span className="text-xs font-mono text-zinc-500 mb-2 block">Step_03</span>
                        <h3 className="text-xl text-white font-medium mb-3">Iterative Drafting</h3>
                        <p className="text-sm text-zinc-500 leading-relaxed">
                            Writing happens in loops. The agent drafts Section A, reviews it against the Style DNA, and then drafts Section B using Section A as context. No disjointed paragraphs.
                        </p>
                    </div>

                </div>
            </div>
            <Crosshair className="-bottom-3 -left-3" />
            <Crosshair className="-bottom-3 -right-3" />
        </div>

        {/* ROW 6: BENTO GRID */}
        <div className="relative border-b border-border p-6 md:p-12 bg-background">
            <div className="mb-16 max-w-2xl">
                 <h2 className="text-3xl font-serif text-white mb-4">The "Black Box" Opened.</h2>
                 <p className="text-zinc-400 font-light">
                    Most AI tools are wrappers. AgenWrite is a transparent pipeline of specialized agents working in concert.
                 </p>
            </div>
            <BentoGrid />
            <Crosshair className="-bottom-3 -left-3" />
            <Crosshair className="-bottom-3 -right-3" />
        </div>

        {/* ROW 7: COMPARISON */}
        <div className="relative border-b border-border py-24 px-6 md:px-12 bg-zinc-900/10">
            <div className="text-center mb-16">
                 <h2 className="text-3xl font-serif text-white mb-4">System Architecture vs. Wrappers</h2>
            </div>
            <ComparisonTable />
            <Crosshair className="-bottom-3 -left-3" />
            <Crosshair className="-bottom-3 -right-3" />
        </div>

        {/* ROW 8: FINAL CTA */}
        <div className="relative py-32 px-6 text-center bg-zinc-950 overflow-hidden">
             {/* Subtle Glow */}
             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-white/5 rounded-full blur-3xl pointer-events-none"></div>

             <div className="relative z-10 max-w-2xl mx-auto">
                 <div className="w-12 h-12 bg-white rounded-sm flex items-center justify-center mx-auto mb-8 shadow-[0_0_20px_rgba(255,255,255,0.2)]">
                    <Sparkles size={24} className="text-black" />
                 </div>
                 <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 tracking-tight">
                    Ready to scale your authority?
                 </h2>
                 <p className="text-zinc-400 mb-10 text-lg font-light">
                    Join 4,000+ teams using the Snowball Method to dominate search.
                 </p>
                 <div className="flex justify-center">
                    <button className="bg-white text-black px-8 py-4 text-sm font-mono font-bold uppercase tracking-widest hover:bg-zinc-200 transition-all flex items-center gap-3">
                        Start Free Trial <ArrowRight size={16} />
                    </button>
                 </div>
             </div>
        </div>

        <Footer />
      </div>
    </div>
  );
};

export default App;