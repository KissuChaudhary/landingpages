import React from 'react';
import { Circle, Hexagon, X, ArrowRight } from 'lucide-react';

export const ProblemSolution: React.FC = () => {
  return (
    <section className="w-full bg-black text-white py-32 border-b border-zinc-900">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        
        {/* Header Section */}
        <div className="mb-24 md:flex md:items-end md:justify-between border-b border-zinc-900 pb-12">
            <div className="max-w-3xl">
                <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-zinc-500 block mb-6">
                    [ 3.0 ] The Paradigm Shift
                </span>
                <h2 className="font-serif text-5xl md:text-6xl text-white leading-[1.1] mb-6">
                    Beyond rigid automation.
                </h2>
                <p className="text-zinc-500 text-lg font-light leading-relaxed max-w-xl">
                    Traditional workflows break under pressure. The Fuse Agentic Layer is designed to adapt, reason, and scale without constant supervision.
                </p>
            </div>
        </div>

        {/* The Comparison Architecture */}
        <div className="w-full">
            {/* Table Header (Hidden on mobile, visible on desktop) */}
            <div className="hidden md:grid grid-cols-2 gap-12 mb-8 px-8">
                <div className="font-mono text-xs uppercase tracking-widest text-zinc-600">
                    // Traditional Automation
                </div>
                <div className="font-mono text-xs uppercase tracking-widest text-white">
                    // The Fuse Agentic Layer
                </div>
            </div>

            {/* Row 1 */}
            <div className="group grid grid-cols-1 md:grid-cols-2 border-t border-zinc-800 transition-all duration-500 hover:bg-zinc-900/20">
                {/* Left (Old) */}
                <div className="p-8 md:p-12 border-b md:border-b-0 md:border-r border-zinc-900 flex flex-col justify-center relative">
                    <div className="md:hidden font-mono text-[10px] uppercase tracking-widest text-zinc-600 mb-4 border-b border-zinc-800 pb-1 inline-block self-start">
                        Traditional
                    </div>
                    <div className="flex items-start gap-6 opacity-50 grayscale transition-all duration-500 group-hover:opacity-30">
                        <div className="mt-1 w-6 h-6 border border-zinc-700 flex items-center justify-center shrink-0">
                            <X size={12} className="text-zinc-500" />
                        </div>
                        <div>
                            <h3 className="text-xl font-medium text-zinc-400 mb-2">Rigid, "If-This-Then-That" logic</h3>
                            <p className="text-sm text-zinc-600 leading-relaxed">
                                Linear scripts that fail when encountering edge cases or unexpected inputs.
                            </p>
                        </div>
                    </div>
                </div>

                {/* Right (New) */}
                <div className="p-8 md:p-12 flex flex-col justify-center relative overflow-hidden">
                    <div className="md:hidden font-mono text-[10px] uppercase tracking-widest text-emerald-500 mb-4 border-b border-emerald-900/30 pb-1 inline-block self-start">
                        Fuse Agentic
                    </div>
                    
                    {/* Hover Glow Effect */}
                    <div className="absolute inset-0 bg-gradient-to-r from-zinc-900/0 via-zinc-900/0 to-zinc-900/0 group-hover:via-zinc-800/10 transition-all duration-700"></div>

                    <div className="relative z-10 flex items-start gap-6">
                        <div className="mt-1 w-6 h-6 bg-white flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(255,255,255,0.3)]">
                            <Hexagon size={12} className="text-black fill-black" />
                        </div>
                        <div>
                            <h3 className="text-xl font-medium text-white mb-2 group-hover:text-white transition-colors">Adaptive reasoning and self-correction</h3>
                            <p className="text-sm text-zinc-400 leading-relaxed group-hover:text-zinc-300 transition-colors">
                                Agents that evaluate outcomes and retry strategies dynamically until the goal is met.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Row 2 */}
            <div className="group grid grid-cols-1 md:grid-cols-2 border-t border-zinc-800 transition-all duration-500 hover:bg-zinc-900/20">
                 {/* Left (Old) */}
                 <div className="p-8 md:p-12 border-b md:border-b-0 md:border-r border-zinc-900 flex flex-col justify-center relative">
                    <div className="md:hidden font-mono text-[10px] uppercase tracking-widest text-zinc-600 mb-4 border-b border-zinc-800 pb-1 inline-block self-start">
                        Traditional
                    </div>
                    <div className="flex items-start gap-6 opacity-50 grayscale transition-all duration-500 group-hover:opacity-30">
                        <div className="mt-1 w-6 h-6 border border-zinc-700 flex items-center justify-center shrink-0">
                             <X size={12} className="text-zinc-500" />
                        </div>
                        <div>
                            <h3 className="text-xl font-medium text-zinc-400 mb-2">Breaks when formats change</h3>
                            <p className="text-sm text-zinc-600 leading-relaxed">
                                Hardcoded selectors and fragile dependencies that shatter with minor updates.
                            </p>
                        </div>
                    </div>
                </div>

                {/* Right (New) */}
                <div className="p-8 md:p-12 flex flex-col justify-center relative overflow-hidden">
                    <div className="md:hidden font-mono text-[10px] uppercase tracking-widest text-emerald-500 mb-4 border-b border-emerald-900/30 pb-1 inline-block self-start">
                        Fuse Agentic
                    </div>
                    <div className="relative z-10 flex items-start gap-6">
                        <div className="mt-1 w-6 h-6 bg-white flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(255,255,255,0.3)]">
                            <Hexagon size={12} className="text-black fill-black" />
                        </div>
                        <div>
                            <h3 className="text-xl font-medium text-white mb-2">Understands context and unstructured data</h3>
                            <p className="text-sm text-zinc-400 leading-relaxed group-hover:text-zinc-300 transition-colors">
                                Uses semantic understanding to process messy inputs, PDFs, and varying web layouts.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Row 3 */}
            <div className="group grid grid-cols-1 md:grid-cols-2 border-t border-b border-zinc-800 transition-all duration-500 hover:bg-zinc-900/20">
                 {/* Left (Old) */}
                 <div className="p-8 md:p-12 border-b md:border-b-0 md:border-r border-zinc-900 flex flex-col justify-center relative">
                    <div className="md:hidden font-mono text-[10px] uppercase tracking-widest text-zinc-600 mb-4 border-b border-zinc-800 pb-1 inline-block self-start">
                        Traditional
                    </div>
                    <div className="flex items-start gap-6 opacity-50 grayscale transition-all duration-500 group-hover:opacity-30">
                        <div className="mt-1 w-6 h-6 border border-zinc-700 flex items-center justify-center shrink-0">
                             <X size={12} className="text-zinc-500" />
                        </div>
                        <div>
                            <h3 className="text-xl font-medium text-zinc-400 mb-2">Requires constant developer upkeep</h3>
                            <p className="text-sm text-zinc-600 leading-relaxed">
                                Every change requires a ticket, a human engineer, and deployment time.
                            </p>
                        </div>
                    </div>
                </div>

                {/* Right (New) */}
                <div className="p-8 md:p-12 flex flex-col justify-center relative overflow-hidden">
                    <div className="md:hidden font-mono text-[10px] uppercase tracking-widest text-emerald-500 mb-4 border-b border-emerald-900/30 pb-1 inline-block self-start">
                        Fuse Agentic
                    </div>
                    <div className="relative z-10 flex items-start gap-6">
                        <div className="mt-1 w-6 h-6 bg-white flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(255,255,255,0.3)]">
                             <Hexagon size={12} className="text-black fill-black" />
                        </div>
                        <div>
                            <h3 className="text-xl font-medium text-white mb-2">Learns and scales with your workflow</h3>
                            <p className="text-sm text-zinc-400 leading-relaxed group-hover:text-zinc-300 transition-colors">
                                As you provide feedback, the agentic layer refines its own execution paths automatically.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
        
        {/* Footer Note */}
        <div className="mt-12 flex items-center justify-end">
            <button className="group flex items-center gap-3 text-sm font-mono uppercase tracking-wider text-white hover:text-zinc-300 transition-colors">
                <span>View Documentation</span>
                <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
            </button>
        </div>

      </div>
    </section>
  );
};