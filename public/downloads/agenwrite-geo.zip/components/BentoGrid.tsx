import React from 'react';
import { Frame } from './ui/Frame';
import { AreaChart, Area, ResponsiveContainer } from 'recharts';
import { FileSearch, GitBranch, Quote, Check } from 'lucide-react';

const waveData = [
  { val: 20 }, { val: 40 }, { val: 30 }, { val: 70 }, { val: 40 }, { val: 60 }, { val: 30 }, { val: 50 }, { val: 20 }, { val: 40 }
];

export const BentoGrid: React.FC = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 md:grid-rows-2 gap-6 w-full">
      
      {/* Box A: The Snowball Method (Large Square) */}
      <Frame className="col-span-1 md:col-span-1 md:row-span-2 min-h-[300px]" label="Core_Logic">
        <div className="flex flex-col h-full justify-between">
          <div>
            <div className="w-10 h-10 bg-zinc-800 border border-zinc-700 flex items-center justify-center mb-4 text-white">
                <GitBranch size={20} />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">The Snowball Method</h3>
            <p className="text-sm text-zinc-400 leading-relaxed">
              Standard AI forgets paragraph 1 by paragraph 5. Ours loops back, creating coherent arguments that flow naturally.
            </p>
          </div>
          
          <div className="mt-8">
            <div className="flex justify-between items-end mb-2">
                <span className="text-[10px] font-mono text-zinc-500 uppercase">Coherence Score</span>
                <span className="text-2xl font-mono font-medium text-white">98.4%</span>
            </div>
            <div className="h-16 w-full">
                <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={waveData}>
                    <defs>
                        <linearGradient id="waveGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#FFFFFF" stopOpacity={0.2}/>
                        <stop offset="95%" stopColor="#FFFFFF" stopOpacity={0}/>
                        </linearGradient>
                    </defs>
                    <Area type="monotone" dataKey="val" stroke="#FFFFFF" strokeWidth={1.5} fill="url(#waveGradient)" />
                    </AreaChart>
                </ResponsiveContainer>
            </div>
          </div>
        </div>
      </Frame>

      {/* Box B: Deep Research Agent (Tall) */}
      <Frame className="col-span-1 md:col-span-1 md:row-span-2" label="Research_Node">
        <div className="flex flex-col h-full">
            <div className="w-10 h-10 bg-zinc-800 border border-zinc-700 flex items-center justify-center mb-4 text-white">
                <FileSearch size={20} />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">Deep Research Agent</h3>
            <p className="text-sm text-zinc-400 leading-relaxed mb-6">
                The agent browsers the live web, reads top competitors, and builds a "Fact Sheet" before writing a single word.
            </p>
            
            <div className="bg-zinc-900/50 border border-zinc-800 p-4 flex-1 flex flex-col gap-3">
                <div className="flex items-center gap-3">
                    <div className="w-4 h-4 rounded-sm bg-green-900/30 border border-green-700/50 flex items-center justify-center text-green-500">
                        <Check size={10} />
                    </div>
                    <span className="text-xs font-mono text-zinc-400">Identifying Knowledge Gaps...</span>
                </div>
                <div className="flex items-center gap-3">
                    <div className="w-4 h-4 rounded-sm bg-green-900/30 border border-green-700/50 flex items-center justify-center text-green-500">
                        <Check size={10} />
                    </div>
                    <span className="text-xs font-mono text-zinc-400">Verifying 2025 Data...</span>
                </div>
                 <div className="flex items-center gap-3">
                    <div className="w-4 h-4 rounded-sm bg-green-900/30 border border-green-700/50 flex items-center justify-center text-green-500">
                        <Check size={10} />
                    </div>
                    <span className="text-xs font-mono text-zinc-400">Filtering Generic Advice...</span>
                </div>
                 <div className="flex items-center gap-3 opacity-50">
                    <div className="w-4 h-4 rounded-sm border border-zinc-700"></div>
                    <span className="text-xs font-mono text-zinc-600">Synthesizing Fact Sheet...</span>
                </div>
            </div>
        </div>
      </Frame>

      {/* Box C: The Style Thief (Wide) */}
      <Frame className="col-span-1 md:col-span-1 md:row-span-2" label="Style_DNA">
         <div className="flex flex-col h-full">
            <div className="w-10 h-10 bg-zinc-800 border border-zinc-700 flex items-center justify-center mb-4 text-white">
                <Quote size={20} />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">The Style Thief</h3>
            <p className="text-sm text-zinc-400 leading-relaxed mb-8">
               We don't just prompt for "tone." We scrape your best work, analyze sentence entropy, and extract your Style DNA.
            </p>
            
            <div className="mt-auto space-y-4">
                <div className="space-y-2">
                    <div className="flex justify-between text-[10px] font-mono uppercase text-zinc-500">
                        <span>The Grey Goo</span>
                        <span>Your Voice</span>
                    </div>
                    <div className="h-2 w-full bg-zinc-800 rounded-full overflow-hidden border border-zinc-700">
                        <div className="h-full bg-white w-[99%] rounded-full"></div>
                    </div>
                </div>
                
                 <div className="p-3 bg-zinc-900/50 border border-zinc-800 text-xs font-mono text-zinc-400 italic">
                    "Style Match: 99.2%. Detected usage of short punchy sentences and technical metaphors."
                 </div>
            </div>
         </div>
      </Frame>

    </div>
  );
};