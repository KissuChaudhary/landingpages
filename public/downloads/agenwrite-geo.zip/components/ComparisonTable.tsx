import React from 'react';
import { Check, X } from 'lucide-react';

export const ComparisonTable: React.FC = () => {
    return (
        <div className="overflow-x-auto w-full max-w-4xl mx-auto border border-border bg-zinc-900/30 backdrop-blur-sm">
            <table className="w-full text-sm text-left">
                <thead className="text-xs text-zinc-500 uppercase bg-zinc-900 border-b border-border font-mono">
                    <tr>
                        <th className="px-6 py-4 font-medium tracking-wider">Feature</th>
                        <th className="px-6 py-4 font-medium tracking-wider text-zinc-600">Generic GPT Wrapper</th>
                        <th className="px-6 py-4 font-medium tracking-wider text-white bg-zinc-800/50 border-l border-zinc-800">AgenWrite Agent</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-border text-zinc-300">
                    <tr className="hover:bg-zinc-800/30 transition-colors">
                        <td className="px-6 py-4 font-mono text-xs text-zinc-500">Architecture</td>
                        <td className="px-6 py-4 text-zinc-500">Single-shot prompt</td>
                        <td className="px-6 py-4 font-medium text-white bg-zinc-800/30 border-l border-zinc-800 flex items-center gap-2">
                             <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span> Multi-step Agentic Chain
                        </td>
                    </tr>
                    <tr className="hover:bg-zinc-800/30 transition-colors">
                        <td className="px-6 py-4 font-mono text-xs text-zinc-500">Research</td>
                        <td className="px-6 py-4 text-zinc-500">Training data only (Outdated)</td>
                        <td className="px-6 py-4 font-medium text-white bg-zinc-800/30 border-l border-zinc-800 flex items-center gap-2">
                             <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span> Live Web Search + Fact Check
                        </td>
                    </tr>
                    <tr className="hover:bg-zinc-800/30 transition-colors">
                        <td className="px-6 py-4 font-mono text-xs text-zinc-500">Tone</td>
                        <td className="px-6 py-4 text-zinc-500">Robot / Generic</td>
                        <td className="px-6 py-4 font-medium text-white bg-zinc-800/30 border-l border-zinc-800 flex items-center gap-2">
                             <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span> Brand-Tuned Replica
                        </td>
                    </tr>
                     <tr className="hover:bg-zinc-800/30 transition-colors">
                        <td className="px-6 py-4 font-mono text-xs text-zinc-500">Optimization Target</td>
                        <td className="px-6 py-4 text-zinc-500">SEO Keywords (Old)</td>
                        <td className="px-6 py-4 font-medium text-white bg-zinc-800/30 border-l border-zinc-800 flex items-center gap-2">
                             <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span> AIO + SEO (Modern)
                        </td>
                    </tr>
                     <tr className="hover:bg-zinc-800/30 transition-colors">
                        <td className="px-6 py-4 font-mono text-xs text-zinc-500">Citation Rate</td>
                        <td className="px-6 py-4 text-zinc-500">Low Probability</td>
                        <td className="px-6 py-4 font-medium text-white bg-zinc-800/30 border-l border-zinc-800 flex items-center gap-2">
                             <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span> High Authority
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    );
};