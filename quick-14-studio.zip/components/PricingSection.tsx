import React from 'react';
import { Check, Bot, Zap, Globe, Image as ImageIcon, Link2, ShieldCheck } from 'lucide-react';
import Button from './Button';

const FeatureItem = ({ icon: Icon, title, description }: { icon: any, title: string, description: string }) => (
  <div className="flex gap-4 items-start group">
    <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-white border border-orange-100 flex items-center justify-center shadow-sm text-orange-500 group-hover:scale-105 transition-transform duration-300">
      <Icon size={20} strokeWidth={1.5} />
    </div>
    <div className="flex-1">
      <h4 className="font-serif text-lg text-stone-900 leading-tight mb-1">
        {title}
      </h4>
      <p className="text-sm text-stone-500 leading-relaxed">
        {description}
      </p>
    </div>
  </div>
);

const PricingSection: React.FC = () => {
  return (
    <section className="w-full max-w-5xl mx-auto px-6 py-20 md:py-32 relative">
      
      {/* Section Header */}
      <div className="flex flex-col items-center text-center mb-16">
        <h2 className="font-serif text-5xl md:text-6xl text-stone-900 mb-6 tracking-tight">
          One Plan. <span className="italic text-stone-500">Unlimited Potential.</span>
        </h2>
        <p className="font-sans text-stone-500 text-lg leading-relaxed max-w-2xl">
          Everything you need to turn search into your biggest growth channel. <br className="hidden md:block" />
          No hidden fees. No complicated tiers. Just results.
        </p>
      </div>

      {/* Wrapper Card (Two-Layer Effect) */}
      <div className="w-full bg-orange-200 rounded-[20px] p-2 shadow-[inset_0_0_0_1px_#c4b5fd">
        
        {/* The Inner Pricing Card */}
        <div className="relative w-full bg-[#fffaf5] border border-orange-100/50 rounded-[17px] overflow-hidden flex flex-col md:flex-row shadow-sm">
            
            {/* Launch Offer Badge (Floating) */}
            <div className="absolute top-0 right-0 md:right-auto md:left-0 z-20">
                <div className="bg-orange-500 text-white text-[10px] font-bold uppercase tracking-widest px-4 py-2 rounded-bl-[24px] md:rounded-br-[24px] md:rounded-bl-none shadow-md">
                    Launch Offer
                </div>
            </div>

            {/* Left Side: Pricing & CTA */}
            <div className="w-full md:w-[40%] bg-gradient-to-b from-orange-50/80 to-white border-b md:border-b-0 md:border-r border-orange-100 p-8 md:p-12 flex flex-col items-center text-center relative">
                
                {/* Handwritten Note */}
                <div className="absolute top-8 right-4 md:-right-6 md:top-20 z-10 pointer-events-none transform rotate-12 md:rotate-0">
                    <div className="relative">
                        <span className="font-hand text-xl text-stone-400 whitespace-nowrap">Save $360/year</span>
                        <svg className="absolute -bottom-6 -left-4 w-12 h-12 text-stone-300 transform rotate-12 hidden md:block" viewBox="0 0 100 100" fill="none" stroke="currentColor">
                            <path d="M80,10 Q40,60 10,80" strokeWidth="2" markerEnd="url(#arrow-price)" />
                            <defs>
                                <marker id="arrow-price" markerWidth="10" markerHeight="10" refX="5" refY="5" orient="auto">
                                    <path d="M0,0 L10,5 L0,10" fill="none" stroke="currentColor" strokeWidth="2" />
                                </marker>
                            </defs>
                        </svg>
                    </div>
                </div>

                <div className="mb-6 mt-4">
                    <span className="inline-block px-3 py-1 rounded-full bg-orange-100 text-orange-700 text-xs font-bold uppercase tracking-wider mb-4 border border-orange-200">
                        All In One
                    </span>
                    <h3 className="font-serif text-2xl text-stone-900">
                        For ambitious entrepreneurs
                    </h3>
                </div>

                <div className="flex items-baseline justify-center gap-3 mb-2">
                    <span className="text-xl text-stone-400 line-through decoration-orange-300/50 decoration-2">
                        $79
                    </span>
                    <span className="text-6xl md:text-7xl font-serif text-stone-900 tracking-tighter">
                        $49
                    </span>
                </div>
                <p className="text-stone-500 text-sm mb-10">per month</p>

          
                
      <div className="flex justify-center">
        <Button variant="primary" className="w-full px-10 py-4 text-lg">
            Win The AEO Race
        </Button>
      </div>

                <div className="mt-6 flex items-center gap-2 text-xs text-stone-400 font-medium">
                    <ShieldCheck size={14} className="text-green-500" />
                    14-day money-back guarantee
                </div>
            </div>

            {/* Right Side: Features */}
            <div className="flex-1 p-8 md:p-12 bg-white">
                <h3 className="font-sans text-xs font-bold text-stone-400 uppercase tracking-widest mb-8 border-b border-stone-100 pb-4">
                    Included Powerhouse Access
                </h3>

                <div className="space-y-8">
                    <FeatureItem 
                        icon={Bot}
                        title="30 Articles / Month"
                        description="Generated and published on auto-pilot. High quality, human-like output that passes AI detection."
                    />
                    <FeatureItem 
                        icon={Zap}
                        title="Strategic Content Planning"
                        description="Hands-free planning based on competitor gaps and real-time search intent analysis."
                    />
                    <FeatureItem 
                        icon={Globe}
                        title="CMS Integration"
                        description="Connects directly with WordPress, Webflow, and Shopify. We handle the formatting."
                    />
                    <FeatureItem 
                        icon={ImageIcon}
                        title="On-Brand AI Images"
                        description="Visuals generated to match your brand's unique style automatically for every post."
                    />
                    <FeatureItem 
                        icon={Link2}
                        title="Smart Interlinking"
                        description="Powerful semantic suggestions to boost site structure and topical authority."
                    />
                </div>
            </div>
        </div>
      </div>
      
      {/* Decorative background blur behind the card */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[110%] h-[90%] bg-orange-100/30 blur-3xl -z-10 rounded-full"></div>

    </section>
  );
};

export default PricingSection;